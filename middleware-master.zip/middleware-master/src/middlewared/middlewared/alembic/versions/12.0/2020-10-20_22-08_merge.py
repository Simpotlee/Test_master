"""Merge

Revision ID: 56016e596321
Revises: 1a191726e5ea, b410e4d0145f
Create Date: 2020-10-20 22:08:42.985220+00:00

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '56016e596321'
down_revision = ('1a191726e5ea', 'b410e4d0145f')
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
