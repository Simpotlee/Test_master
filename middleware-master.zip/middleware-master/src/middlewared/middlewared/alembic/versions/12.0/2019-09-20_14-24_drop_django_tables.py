"""Drop Django tables

Revision ID: 0d545b21e189
Revises: c6be4fe10acc
Create Date: 2019-09-20 14:24:39.828978+00:00

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '0d545b21e189'
down_revision = 'e49fadd7285d'
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
