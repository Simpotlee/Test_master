"""Merge

Revision ID: c55b034b7654
Revises: 7310292225d3, 7035fa70c0c0
Create Date: 2023-03-22 19:52:57.080579+00:00

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'c55b034b7654'
down_revision = ('7310292225d3', '7035fa70c0c0')
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
