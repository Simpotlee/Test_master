"""Merge

Revision ID: e1c7ee02b545
Revises: 9c44b7e06dff, 004f0934ff0f
Create Date: 2023-01-26 22:31:27.803074+00:00

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'e1c7ee02b545'
down_revision = ('9c44b7e06dff', '004f0934ff0f')
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
