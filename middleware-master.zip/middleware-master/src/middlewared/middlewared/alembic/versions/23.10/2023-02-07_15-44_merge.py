"""Merge

Revision ID: 653ea1a2ba57
Revises: eaadca673130, 1f39ac35aaeb
Create Date: 2023-02-07 15:44:00.629175+00:00

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '653ea1a2ba57'
down_revision = ('eaadca673130', '1f39ac35aaeb')
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
