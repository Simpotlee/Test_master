"""Merge

Revision ID: 91a4e09f5b7a
Revises: 54beb9f4bdf5, b690e5ae986d
Create Date: 2023-03-10 09:30:00.629175+00:00

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '91a4e09f5b7a'
down_revision = ('54beb9f4bdf5', 'b690e5ae986d')
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
