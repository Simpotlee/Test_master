"""Merge

Revision ID: 54beb9f4bdf5
Revises: 60a953d6da3a, 9694ff0f4de6
Create Date: 2023-02-27 16:02:00.629175+00:00

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '54beb9f4bdf5'
down_revision = ('60a953d6da3a', '9694ff0f4de6')
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
