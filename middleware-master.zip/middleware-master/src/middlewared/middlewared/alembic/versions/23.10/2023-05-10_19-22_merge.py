"""Merge

Revision ID: 58a555dd9612
Revises: b2775ae20e88, 08539dfd0500
Create Date: 2023-05-10 19:22:29.283266+00:00

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '58a555dd9612'
down_revision = ('b2775ae20e88', '08539dfd0500')
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
