"""Merge

Revision ID: 519c9d598091
Revises: a5584351bdb8, 67ee25d22253
Create Date: 2023-01-16 10:51:51.496712+00:00

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '519c9d598091'
down_revision = ('a5584351bdb8', '67ee25d22253')
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
