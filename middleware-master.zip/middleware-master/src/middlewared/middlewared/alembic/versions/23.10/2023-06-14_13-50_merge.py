"""Merge

Revision ID: 0893833a57be
Revises: 3c011188cbe2, 1490eef1fa8d
Create Date: 2023-06-14 13:50:49.024034+00:00

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '0893833a57be'
down_revision = ('3c011188cbe2', '1490eef1fa8d')
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
