"""Merge

Revision ID: a5584351bdb8
Revises: d81ede53eb14, c86a02e21e9d
Create Date: 2023-01-15 10:51:51.496712+00:00

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'a5584351bdb8'
down_revision = ('d81ede53eb14', 'c86a02e21e9d')
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
