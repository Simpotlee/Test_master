"""Merge

Revision ID: eaadca673130
Revises: e1c7ee02b545, af5efb72c74f
Create Date: 2023-01-27 16:53:39.823376+00:00

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'eaadca673130'
down_revision = ('e1c7ee02b545', 'af5efb72c74f')
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
