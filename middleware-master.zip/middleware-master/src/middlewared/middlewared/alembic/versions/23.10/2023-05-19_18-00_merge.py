"""Merge

Revision ID: a70b230c1675
Revises: 58a555dd9612, 441144fa08e7
Create Date: 2023-05-19 18:00:29.283266+00:00

"""

# revision identifiers, used by Alembic.
revision = 'a70b230c1675'
down_revision = ('58a555dd9612', '441144fa08e7')
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
