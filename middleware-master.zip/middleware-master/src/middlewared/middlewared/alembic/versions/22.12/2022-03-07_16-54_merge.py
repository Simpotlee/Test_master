"""Merge

Revision ID: 455ac50fe299
Revises: 77832a4aeca8, 4e027c93e4d1
Create Date: 2022-03-07 16:54:21.691455+00:00

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '455ac50fe299'
down_revision = ('77832a4aeca8', '4e027c93e4d1')
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
