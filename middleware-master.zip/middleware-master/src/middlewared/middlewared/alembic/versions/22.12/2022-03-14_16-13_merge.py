"""Merge

Revision ID: 0b02e21a1a10
Revises: 53fc4f0a6ffc, 6980b63de512
Create Date: 2022-03-14 16:13:11.572629+00:00

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '0b02e21a1a10'
down_revision = ('53fc4f0a6ffc', '6980b63de512')
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
