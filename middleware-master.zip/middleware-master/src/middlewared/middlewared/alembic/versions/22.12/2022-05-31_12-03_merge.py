"""Merge

Revision ID: 9df2ef0f7f32
Revises: bca4e75ed8fc, a3ee46e3860e
Create Date: 2022-05-31 11:58:53.419222+00:00

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '9df2ef0f7f32'
down_revision = ('bca4e75ed8fc', 'a3ee46e3860e')
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
