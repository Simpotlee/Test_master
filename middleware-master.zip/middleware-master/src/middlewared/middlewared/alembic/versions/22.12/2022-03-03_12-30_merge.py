"""Merge

Revision ID: 77832a4aeca8
Revises: a2ae33484fed, c09a16ca3399
Create Date: 2020-10-23 14:36:28.587671+00:00

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '77832a4aeca8'
down_revision = ('a2ae33484fed', '2ed09f3b17b7')
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
