"""Merge

Revision ID: 53fc4f0a6ffc
Revises: 455ac50fe299, b3c5a5321aef
Create Date: 2020-10-23 14:36:28.587671+00:00

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '53fc4f0a6ffc'
down_revision = ('455ac50fe299', 'b3c5a5321aef')
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
