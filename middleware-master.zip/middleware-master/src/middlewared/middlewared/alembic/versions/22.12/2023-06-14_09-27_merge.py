"""Merge

Revision ID: 1490eef1fa8d
Revises: 441144fa08e7, b412304844e1
Create Date: 2023-06-14 09:27:30.734506+00:00

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '1490eef1fa8d'
down_revision = ('441144fa08e7', 'b412304844e1')
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
