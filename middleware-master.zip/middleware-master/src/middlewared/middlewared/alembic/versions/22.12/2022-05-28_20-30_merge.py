"""
Merge Migration

Revision ID: a719566695c3
Revises: 59fbc9897ec3, 8b6d0edc6a38
Create Date: 2022-05-28 20:30:01.759559+00:00

"""

revision = 'a719566695c3'
down_revision = ('59fbc9897ec3', '8b6d0edc6a38')
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
