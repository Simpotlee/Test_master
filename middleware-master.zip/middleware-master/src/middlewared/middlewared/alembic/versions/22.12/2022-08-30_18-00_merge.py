"""Merge

Revision ID: eba33d756a77
Revises: daaf691ed483, 98b2cfaa0e5a
Create Date: 2022-08-30 18:00:11.301224+00:00

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'eba33d756a77'
down_revision = ('daaf691ed483', '98b2cfaa0e5a')
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
