"""merge

Revision ID: 6e73632d6e88
Revises: d46d345ef8a8, 19eb67dcdee2
Create Date: 2022-04-01 17:28:01.759559+00:00

"""

# revision identifiers, used by Alembic.
revision = '6e73632d6e88'
down_revision = ('d46d345ef8a8', '19eb67dcdee2')
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
