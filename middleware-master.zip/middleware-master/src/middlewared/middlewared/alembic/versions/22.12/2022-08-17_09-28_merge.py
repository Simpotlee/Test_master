"""Merge

Revision ID: e3a81e1c2135
Revises: 9b7127606e2b, 7c8da45b515e
Create Date: 2022-08-17 09:28:11.301224+00:00

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'e3a81e1c2135'
down_revision = ('9b7127606e2b', '7c8da45b515e')
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
