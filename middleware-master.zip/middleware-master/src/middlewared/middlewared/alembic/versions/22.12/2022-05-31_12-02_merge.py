"""Merge

Revision ID: bca4e75ed8fc
Revises: 0267cef97ec3, a719566695c3
Create Date: 2022-05-31 12:02:05.164214+00:00

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'bca4e75ed8fc'
down_revision = ('0267cef97ec3', 'a719566695c3')
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
