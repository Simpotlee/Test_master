"""Merge

Revision ID: 13cd7cf67438
Revises: daa17e858eaf, ae629228373b
Create Date: 2021-02-10 13:53:44.195725+00:00

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '13cd7cf67438'
down_revision = ('daa17e858eaf', 'ae629228373b')
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
