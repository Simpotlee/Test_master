"""Merge

Revision ID: b140ab0d3066
Revises: 674afdc2a00b, 7132a60093ce
Create Date: 2022-01-05 16:55:42.969495+00:00

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'b140ab0d3066'
down_revision = ('674afdc2a00b', '7132a60093ce')
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
