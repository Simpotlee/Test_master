"""Merge

Revision ID: a3f3b07bb1aa
Revises: daec6faa9589, 99ddc485eac2
Create Date: 2021-12-13 14:58:59.219006+00:00

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'a3f3b07bb1aa'
down_revision = ('daec6faa9589', '99ddc485eac2')
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
