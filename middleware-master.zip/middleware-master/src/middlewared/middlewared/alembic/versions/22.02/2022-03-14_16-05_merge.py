"""Merge

Revision ID: 6980b63de512
Revises: 8c9ad60244de, 503adaba1f57
Create Date: 2022-03-14 16:05:07.390690+00:00

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '6980b63de512'
down_revision = ('8c9ad60244de', '503adaba1f57')
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
