"""Merge

Revision ID: 3376b7a70d17
Revises: e38dee348a88, 90b815426c10
Create Date: 2020-10-23 15:08:57.583858+00:00

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '3376b7a70d17'
down_revision = ('e38dee348a88', '90b815426c10')
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
