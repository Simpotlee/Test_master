"""Merge

Revision ID: dcbe68f23a89
Revises: 6e41203881b2, 9c11f6c6f152
Create Date: 2021-12-27 11:19:58.604623+00:00

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'dcbe68f23a89'
down_revision = ('6e41203881b2', '9c11f6c6f152')
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
