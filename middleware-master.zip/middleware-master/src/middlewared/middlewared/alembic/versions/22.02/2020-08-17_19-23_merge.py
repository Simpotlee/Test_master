"""Merge

Revision ID: 7c9a051a3f47
Revises: 9c0795f22577, a3298f120609
Create Date: 2020-08-17 19:23:56.140480+00:00

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '7c9a051a3f47'
down_revision = ('9c0795f22577', 'a3298f120609')
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
