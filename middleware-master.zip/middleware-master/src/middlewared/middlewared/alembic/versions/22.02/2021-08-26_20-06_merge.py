"""
Merge

Revision ID: 8e991f9adcdf
Revises: a05844ffb381, 26de83f45a9d
Create Date: 2021-08-26 20:06:57.583858+00:00

"""
revision = '8e991f9adcdf'
down_revision = ('a05844ffb381', '26de83f45a9d')
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
