"""Merge

Revision ID: 4a1c851b6ee6
Revises: 4eaafe146314, 50c8360d9616
Create Date: 2021-03-31 13:05:46.285689+00:00

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '4a1c851b6ee6'
down_revision = ('4eaafe146314', '50c8360d9616')
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
