"""Merge

Revision ID: 2076c53a1a28
Revises: df19c1a8d4ae, fee786dfe121
Create Date: 2021-10-12 19:08:13.314329+00:00

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '2076c53a1a28'
down_revision = ('df19c1a8d4ae', 'fee786dfe121')
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
