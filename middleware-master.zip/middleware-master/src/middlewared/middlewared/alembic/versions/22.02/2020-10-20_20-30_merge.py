"""Merge

Revision ID: 264ac0d5da22
Revises: c9900d2d11cb, 56016e596321
Create Date: 2020-10-20 20:30:06.059582+00:00

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '264ac0d5da22'
down_revision = ('c9900d2d11cb', '56016e596321')
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
