"""Merge

Revision ID: e22c96fb9959
Revises: 20de5cd53d23, 2e2c8b0e787b
Create Date: 2021-05-10 13:50:54.645943+00:00

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'e22c96fb9959'
down_revision = ('20de5cd53d23', '2e2c8b0e787b')
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
