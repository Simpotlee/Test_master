"""Merge

Revision ID: 8f72494885e6
Revises: ecd42897802c, 99aef90c4cd6
Create Date: 2022-02-11 20:29:59.858828+00:00

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '8f72494885e6'
down_revision = ('ecd42897802c', '99aef90c4cd6')
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
