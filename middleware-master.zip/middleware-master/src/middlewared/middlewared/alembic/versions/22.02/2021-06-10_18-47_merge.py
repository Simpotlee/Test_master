"""Merge

Revision ID: 1fd17693941f
Revises: 737912c7a9c1, 5f4cab067712
Create Date: 2021-06-10 18:47:43.400614+00:00

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '1fd17693941f'
down_revision = ('737912c7a9c1', '5f4cab067712')
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
