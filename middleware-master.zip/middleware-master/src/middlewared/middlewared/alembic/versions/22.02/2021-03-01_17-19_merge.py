"""Merge

Revision ID: d9e9d467fb39
Revises: 13cd7cf67438, dc143ce20fcd
Create Date: 2021-03-01 17:19:21.704702+00:00

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'd9e9d467fb39'
down_revision = ('13cd7cf67438', 'dc143ce20fcd')
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
