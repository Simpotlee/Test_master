"""merge

Revision ID: 19eb67dcdee2
Revises: 6980b63de512, 88bfe11b5be5
Create Date: 2022-04-01 16:09:55.446715+00:00

"""

# revision identifiers, used by Alembic.
revision = '19eb67dcdee2'
down_revision = ('6980b63de512', '88bfe11b5be5')
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
