"""Merge

Revision ID: e38dee348a88
Revises: 77d2af1b121d, c09a16ca3399
Create Date: 2020-10-23 14:36:28.587671+00:00

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'e38dee348a88'
down_revision = ('77d2af1b121d', 'c09a16ca3399')
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
