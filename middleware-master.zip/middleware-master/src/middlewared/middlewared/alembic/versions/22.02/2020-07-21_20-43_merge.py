"""Merge

Revision ID: df8ce67e4828
Revises: 57a7094944d7, 6d3efdc7ba5b
Create Date: 2020-07-21 20:43:48.295514+00:00

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'df8ce67e4828'
down_revision = ('57a7094944d7', '6d3efdc7ba5b')
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
