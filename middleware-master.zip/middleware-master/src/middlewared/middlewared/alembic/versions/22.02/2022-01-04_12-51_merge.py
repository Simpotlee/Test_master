"""Merge

Revision ID: 9e5e27934a42
Revises: dcbe68f23a89, 37298ef77ee8
Create Date: 2022-01-04 12:51:27.801313+00:00

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '9e5e27934a42'
down_revision = ('dcbe68f23a89', '37298ef77ee8')
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
