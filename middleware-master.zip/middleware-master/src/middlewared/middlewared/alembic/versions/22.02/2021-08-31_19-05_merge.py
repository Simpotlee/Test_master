"""
Merge

Revision ID: b55d888749aa
Revises: 8e991f9adcdf, 45d6f6f07b0f
Create Date: 2021-08-31 19:05:57.583858+00:00

"""
revision = 'b55d888749aa'
down_revision = ('8e991f9adcdf', '45d6f6f07b0f')
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
