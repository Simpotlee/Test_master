class JobTimeOut(Exception):
    """raised when waiting on a job times out"""
    pass
