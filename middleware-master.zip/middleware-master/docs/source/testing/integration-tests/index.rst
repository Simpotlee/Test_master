Integration Testing
===================


.. toctree::
   :maxdepth: 1
   :caption: Contents:

   mock.rst

TrueNAS middleware includes integration test routines that performs REST and WebSocket API requests to a test VM
installation, checks responses and observes various OS and software components behavior to ensure it matches
our expectations.
