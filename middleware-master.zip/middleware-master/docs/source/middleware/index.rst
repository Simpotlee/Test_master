Middleware Daemon
=================

.. toctree::
    :maxdepth: 1
    :caption: Contents:

    development.rst
    process_pool.rst
    jobs.rst
    plugins/index.rst
