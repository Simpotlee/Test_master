Simulating real-world conditions
================================

.. toctree::
   :maxdepth: 1
   :caption: Contents:

   cpu-temperature-reporting.rst
   scrub.rst
